# Supplementary information

**Article:** Privacy-Preserving Report-Bound Spatiotemporal Verification for Vehicular Crowdsensing  
**Journal:** Telecommunication Systems  
**Authors:** Lili He, Sheng Jiang, Shuang Chen, Lei Zhang  
**Affiliation:** College of Information and Electronic Technology, Jiamusi University, Jiamusi 154007, China  
**Corresponding author:** Lei Zhang, 8213662@163.com

The `prototype/` directory contains the software prototype and tests. `experiments/` contains the experimental records and reproduction instructions. `context_hiding_extensions_test.go` with `experiments/context_hiding_extensions.log` records the hidden-context variants of all four circuits and their acceptance-path measurements (30 runs per variant after one warm-up, plus substituted-context, substituted-holder and duplicate-nullifier checks). `protocol_comparison_test.go` with `experiments/protocol_comparison.log` records the same-task, same-process three-arm comparison of the shared-context active circuit, the hidden-context active circuit and a trusted-issuer plus task-pseudonym baseline without zero-knowledge proofs, including baseline rejection checks and an issuer cross-task linkability check. The original base-circuit candidate (`context_hiding_candidate_test.go`, `experiments/context_hiding_candidate.log`) remains an exploratory check described in `安全修订与候选方案.md`.
