Author-review draft; not approved for submission.
Target: Vehicular Communications. Publisher official elsarticle 3.4.
Journal-specific Guide for Authors could not be verified (HTTP 403).
Author order, affiliation, corresponding author/email and funding supplied by the user on 2026-09-22.
Sponsor roles, other declarations and all-author final approval remain pending.
Figure AI disclosures and the general AI statement are deferred for author completion before submission.
Compile: latexmk -pdf -interaction=nonstopmode -halt-on-error paper_a.tex
Highlights are draft supporting text, not confirmed mandatory journal content.
No experiment raw data, private keys or reviewer letters are included.
